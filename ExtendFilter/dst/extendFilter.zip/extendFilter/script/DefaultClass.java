public static Object main(Object ARG){
	if(null==ARG) return null;
	String record=ARG.toString().trim();
	if(0==record.length()) return null;
	String[] arr=record.split("-");
	StringBuilder builder=new StringBuilder("");
	for(int i=0;i<arr.length;i++) builder.append(arr[i]).append(",");
	if(0!=builder.length()) builder.deleteCharAt(builder.length()-1);
	return builder.toString();
}