import com.lc.plugin.extend.filter.util.ZipUtil;
public class DefaultClass {
	public static Object main(Object ARG){
		if(null==ARG) return null;
		String zipRecord=ARG.toString().trim();
		try {
			return ZipUtil.uncompressFromString(zipRecord);
		} catch (Exception e) {;
			e.printStackTrace();
		}
		return null;
	}
}