public class DefaultClass {
	
	public Object[] main(String message,String[] itemList) {
		return new Object[]{message,new int[]{0,1}};
	}
}