public class DefaultClass {
	
	public int[] main(String[] flowList, String message) {
		return new int[]{0,1};
	}
}